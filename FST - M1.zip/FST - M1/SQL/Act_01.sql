REM   Script: Act_01
REM   Salesman create table

create table salesname;

CREATE TABLE salesman;

CREATE TABLE salesman();

CREATE TABLE salesman( 
 Salesman_id int, 
 salesman_name varchar2(20), 
 salesman_city varchar2(20), 
 comission int 
);

Describe salesman