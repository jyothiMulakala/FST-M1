REM   Script: Act_03
REM   Salesman where condition

Select * from salesman;

select SALESMAN_ID , SALESMAN_CITY from salesman;

select * from salesman where SALESMAN_CITY = 'Paris';

SELECT SALESMAN_ID, COMISSION FROM salesman WHERE SALESMAN_NAME='Paul Adam';