REM   Script: Act_02
REM   Salesman Insert table

INSERT INTO salesman Values (5001,'James Hoog','New York',15);

INSERT INTO salesman Values (5002,'Nail Knite','Paris',13);

INSERT INTO salesman Values (5005,'Pit Alex','London',11);

INSERT INTO salesman Values (5006,'McLyon','Paris',14);

INSERT INTO salesman Values (5007,'Paul Adam','Rome',13);

INSERT INTO salesman Values (5003,'Lauson Hen','San Jose',12);

Select * from salesman;